<?php
require_once dirname(__FILE__).'/config.php';

//przekazanie żądania do następnego dokumentu ("forward")
require_once _ROOT_PATH.'/app/lib/smarty/Smarty.class.php';
include _ROOT_PATH."/app/calc.php";